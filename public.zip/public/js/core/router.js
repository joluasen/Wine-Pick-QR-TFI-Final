// public/js/core/router.js
/**
 * Router SPA - Sistema de navegación unificado
 * 
 * Responsabilidades:
 * - Resolver vistas basadas en el hash de la URL
 * - Cargar vistas parciales dinámicamente
 * - Inyectar navegación según contexto (público/admin)
 * - Manejar rutas protegidas
 * - Gestionar el modal QR como ruta especial
 */

import { getBasePath, fetchJSON, getHashParams } from './utils.js';
import { modalManager } from './modalManager.js';

// Configuración de rutas
const ROUTES = {
  '': 'home',
  '#home': 'home',
  '#login': 'login',
  '#search': 'search',
  '#admin': 'admin',
  '#promos': 'promotions',
  '#promotions': 'promotions',
  '#scan': 'scan' // Ruta especial para el modal QR
};

const PROTECTED_ROUTES = ['admin'];
const PUBLIC_ROUTES = ['home', 'login', 'search', 'promotions', 'scan'];
const DEFAULT_ROUTE = 'home';

// Cache de vistas cargadas
const viewCache = new Map();

// Estado del router
let currentView = null;
let isNavigating = false;

/**
 * Verifica si el usuario está autenticado
 */
async function checkAuth() {
  try {
    const response = await fetch('./api/admin/me', {
      headers: { Accept: 'application/json' }
    });
    return response.ok;
  } catch {
    return false;
  }
}

/**
 * Obtiene el nombre de la vista desde el hash actual
 */
function getViewFromHash() {
  const hash = window.location.hash.split('?')[0] || '#home';
  return ROUTES[hash] || DEFAULT_ROUTE;
}

/**
 * Carga la navegación apropiada según el contexto
 */
async function loadNavigation(viewName) {
  const navContainer = document.getElementById('nav-container');
  const sidebarContainer = document.getElementById('sidebar-container');
  
  const isPublic = PUBLIC_ROUTES.includes(viewName);
  const navFile = isPublic ? 'nav-public.html' : 'nav-admin.html';
  
  try {
    const basePath = getBasePath();
    const response = await fetch(`${basePath}views/partials/${navFile}`, { 
      cache: 'no-store' 
    });
    
    if (response.ok) {
      const html = await response.text();
      
      if (navContainer) navContainer.innerHTML = html;
      if (sidebarContainer) sidebarContainer.innerHTML = html;
      
      setupNavigationListeners();
      updateActiveNavItem();
    }
  } catch (err) {
    console.error('Error cargando navegación:', err);
  }
}

/**
 * Carga el header de búsqueda
 */
async function loadSearchHeader() {
  const mobileSearch = document.getElementById('mobile-search-header');
  const desktopSearch = document.getElementById('desktop-search-header');
  
  if (!mobileSearch && !desktopSearch) return;
  
  try {
    const basePath = getBasePath();
    const response = await fetch(`${basePath}views/partials/search-header.html`, {
      cache: 'no-store'
    });
    
    if (response.ok) {
      const html = await response.text();
      if (mobileSearch) mobileSearch.innerHTML = html;
      if (desktopSearch) desktopSearch.innerHTML = html;
      
      initSearchListeners();
    }
  } catch (err) {
    console.error('Error cargando buscador:', err);
  }
}

/**
 * Configura los listeners de navegación
 */
function setupNavigationListeners() {
  // Usar event delegation para evitar listeners duplicados
  const containers = ['nav-container', 'sidebar-container'];
  
  containers.forEach(containerId => {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    // Remover listener anterior si existe
    container.removeEventListener('click', handleNavClick);
    container.addEventListener('click', handleNavClick);
  });
}

/**
 * Handler para clicks de navegación (event delegation)
 */
function handleNavClick(e) {
  const link = e.target.closest('[data-link]');
  if (!link) return;
  
  e.preventDefault();
  const target = link.getAttribute('data-link');
  
  if (target) {
    navigate(target);
  }
}

/**
 * Actualiza el item activo en la navegación
 */
function updateActiveNavItem() {
  const currentHash = window.location.hash.split('?')[0] || '#home';
  
  document.querySelectorAll('[data-link]').forEach(item => {
    const itemHash = item.getAttribute('data-link');
    
    if (itemHash === currentHash) {
      item.classList.add('active');
    } else {
      item.classList.remove('active');
    }
  });
}

/**
 * Inicializa los listeners del buscador
 */
function initSearchListeners() {
  const form = document.getElementById('searchForm');
  const input = document.getElementById('searchInput');
  
  if (!form) return;
  
  // Submit del formulario
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const query = input?.value?.trim();
    
    if (query) {
      navigate(`#search?query=${encodeURIComponent(query)}`);
      input?.blur();
    }
  });
  
  // Restaurar valor del input si hay query en el hash
  const params = getHashParams();
  if (params.query && input) {
    input.value = params.query;
  }
}

/**
 * Carga e inicializa una vista
 */
async function loadView(viewName) {
  const root = document.getElementById('app-root');
  if (!root) return;
  
  // Prevenir navegación concurrente
  if (isNavigating) return;
  isNavigating = true;
  
  try {
    // Manejar ruta especial #scan (modal QR)
    if (viewName === 'scan') {
      modalManager.showQrScanner();
      isNavigating = false;
      return;
    }
    
    // Verificar autenticación para rutas protegidas
    if (PROTECTED_ROUTES.includes(viewName)) {
      const isAuth = await checkAuth();
      if (!isAuth) {
        isNavigating = false;
        navigate('#login');
        return;
      }
    }
    
    // Cargar header y navegación
    await Promise.all([
      loadSearchHeader(),
      loadNavigation(viewName)
    ]);
    
    // Cargar HTML de la vista
    const basePath = getBasePath();
    let html;
    
    if (viewCache.has(viewName)) {
      html = viewCache.get(viewName);
    } else {
      const response = await fetch(`${basePath}views/${viewName}.html`, {
        cache: 'no-store'
      });
      
      if (!response.ok) {
        throw new Error(`Vista no encontrada: ${viewName}`);
      }
      
      html = await response.text();
      viewCache.set(viewName, html);
    }
    
    root.innerHTML = html;
    
    // Inicializar la vista
    await initializeView(viewName, root);
    
    // Actualizar estado
    currentView = viewName;
    
    // Scroll al inicio
    root.scrollTop = 0;
    
  } catch (err) {
    console.error('Error cargando vista:', err);
    root.innerHTML = `
      <div class="error-view">
        <h2>Error al cargar la página</h2>
        <p>${err.message}</p>
        <button onclick="window.location.hash='#home'" class="btn-primary">
          Volver al inicio
        </button>
      </div>
    `;
  } finally {
    isNavigating = false;
  }
}

/**
 * Inicializa la lógica específica de cada vista
 */
async function initializeView(viewName, container) {
  // Importar e inicializar el módulo de la vista dinámicamente
  const viewModules = {
    home: () => import('../views/homeView.js'),
    login: () => import('../views/loginView.js'),
    search: () => import('../views/searchView.js'),
    admin: () => import('../views/adminView.js'),
    promotions: () => import('../views/promotionsView.js')
  };
  
  const moduleLoader = viewModules[viewName];
  
  if (moduleLoader) {
    try {
      const module = await moduleLoader();
      const initFn = module[`init${capitalize(viewName)}View`];
      
      if (typeof initFn === 'function') {
        await initFn(container);
      }
    } catch (err) {
      console.error(`Error inicializando vista ${viewName}:`, err);
    }
  }
}

/**
 * Capitaliza la primera letra
 */
function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

/**
 * Navega a una ruta específica
 */
export function navigate(hash) {
  if (window.location.hash !== hash) {
    window.location.hash = hash;
  } else {
    // Si el hash es el mismo, forzar recarga
    handleHashChange();
  }
}

/**
 * Handler para cambios de hash
 */
function handleHashChange() {
  const viewName = getViewFromHash();
  loadView(viewName);
}

/**
 * Inicializa el router
 */
export function initRouter() {
  // Inicializar modal manager
  modalManager.init();
  
  // Escuchar cambios de hash
  window.addEventListener('hashchange', handleHashChange);
  
  // Cargar vista inicial
  handleHashChange();
}

/**
 * Obtiene la vista actual
 */
export function getCurrentView() {
  return currentView;
}
